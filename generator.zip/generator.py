#--*coding: utf-8 -*-
from random import choice
def makepassword():
	letter1=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
	letter2=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
	symbol1=["!","@","#","$","%","^","&","*","(",")",",",".","/","?",]
	number1= ["1","2","3","4","5","6","7","8","9","0"]
	print("Strong Password")
	print("Your new password is: ")
	password=(choice(letter1)+choice(symbol1)+choice(letter2)+choice(number1)+choice(letter1)+choice(number1)+choice(letter2)+choice(symbol1))
	print(password)
	decision=raw_input("Would you like me to write a password to a text file Y/N?")
	if decision=="Y"or"Yes"or"yes":
		writing=open("Generated password.txt","w")
		writing.write(password)
		makepassword()
	else:
		break()
			



