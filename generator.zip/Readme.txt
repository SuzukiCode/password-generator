Welcome to Password Generator!

Before you can run this you will need to install Python2.7.
Once installed, you can run the script just by double clicking.

Have fun!